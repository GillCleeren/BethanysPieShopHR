﻿namespace BethanysPieShopHRM.Shared
{
    public interface ITableModel
    {
        bool HighLightRow { get; }
        bool ShowChildTemplate { get; }
    }
}
