﻿namespace BethanysPieShopHRM.Shared
{
    public class JobCategory
    {
        public int JobCategoryId { get; set; }
        public string JobCategoryName { get; set; }
    }
}
